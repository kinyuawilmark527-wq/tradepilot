# TradePilot — Deriv Trading + Partner Edition

This package is a starter web application for a Deriv-connected trading interface.

## Added partner features
- Deriv referral-link field and Create Deriv Account button
- Partner Centre dashboard placeholders for referred clients, activity, commission and API markup
- Server routes for Deriv Partners analytics, client-tag checks and application markup statistics
- Partner disclosure explaining that TradePilot does not hold client funds or place trades for users

## Important
Partner reporting endpoints require the authenticated Deriv account to have the appropriate partner/API permissions. Do not put Deriv secrets in the browser.

Deriv currently documents OAuth 2.0 for web applications and partner REST endpoints for analytics, client tags and markup statistics. Review Deriv's current partner/API terms before launch.

## Environment
Set these before deployment:
- DERIV_CLIENT_ID
- DERIV_CLIENT_SECRET
- DERIV_REDIRECT_URI
- DERIV_APP_ID (if required by your selected API authentication flow)
- SESSION_SECRET
- PORT

Run:
```bash
npm install
npm start
```
